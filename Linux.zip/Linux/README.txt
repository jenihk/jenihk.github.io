LINUX SCAN JAVA v1

1. Download or copy linux-scan-java-v1.sh to your Linux computer
2. Make sure you have the file on root
3. Assign permissions using command chmod +x linux-scan-java-v1.sh
4. Execute command: ./linux-scan-java-v1.sh
5. Copy the results to a text file and save it as <hostname>_Java.txt (Replace <hostname> per computer name that was scanned)
6. Also, please include the responses for following questions:
	a. Where do you executed the script: from a server or from a laptop?
	b. Could you please inform site name/code where this computer belongs, if applicable?
	c. Could you please inform Business Function this computer belongs (mark with a X)?

		[] ADAMA
		[] Corporate Commercial
		[] Corporate Finance
		[] Corporate HR
		[] Corporate Infrastructure
		[] Corporate Legal
		[] Corporate SAP + D&A
		[] CP Commercial
		[] CP Global
		[] CP P+S
		[] CP R+D
		[] CP RDIT
		[] DPE, Cropwise & Belo
		[] Regional APAC
		[] Regional EAME
		[] Regional LATAM
		[] Regional NAFTA
		[] Seeds Commercial
		[] Seeds P+S
		[] Seeds R+D
		[] Seeds RDIT
		[] Syngenta Group China

7. Send the text file to ricardo.domingos@syngenta.com with subject [JAVA SCANNING]