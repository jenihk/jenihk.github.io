LINUX SCAN JAVA v1

1.将linux-scan-java-v1.txt修改为linux-scan-java-v1.sh
2.将linux-scan-java-v1.sh拷贝至Linux主机
3.确保文件位于root目录
4.使用命令"chmod +x linux-scan-java-v1.sh"为脚本赋予权限
5.执行命令"./linux-scan-java-v1.sh"
6. 将脚本检测结果填写至反馈表，并将反馈表邮件至SgcVmdrTeam@Syngentagroup.cn